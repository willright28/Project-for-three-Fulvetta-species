boundry_1 fratercula和davidi边界
boundry_2 hueti和davidi边界
hybridzone 杂交区
range_boundry 分布区
range_boundry 带有物种边界的分布区
hybridzone 带有物种边界和杂交边界的分布区